python main.py
pause
